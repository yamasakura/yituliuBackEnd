# yituliuBackEnd
项目框架:
![](https://img.shields.io/badge/SpringBoot-2.5.5-brightgreen) ![](https://img.shields.io/badge/Mysql-5.7以上-brightgreen)

联系我们：
[![](https://img.shields.io/badge/dynamic/json?color=FE7398&label=bilibili&prefix=%E7%B2%89%E4%B8%9D%E6%95%B0%3A&query=%24.data.totalSubs&url=https%3A%2F%2Fapi.spencerwoo.com%2Fsubstats%2F%3Fsource%3Dbilibili%26queryKey%3D688411531)](https://space.bilibili.com/688411531)


## 一图流后端

## 运行环境
- 下载后将application.txt修改为application.properties
- 放开注释application.properties中的penguin.path、frontEnd.path、frontEnd.backups并修改到resources层级下，用来存放json文件
 - 数据库文件在resources下的EasyExcel.zip