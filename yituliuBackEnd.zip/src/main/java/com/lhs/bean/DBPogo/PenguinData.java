package com.lhs.bean.DBPogo;

public class PenguinData {
}
