package com.lhs.bean.pojo;

public class ItemCost {

    private String itemName;
    private Integer itemNeed;

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getItemNeed() {
        return itemNeed;
    }

    public void setItemNeed(Integer itemNeed) {
        this.itemNeed = itemNeed;
    }
}
