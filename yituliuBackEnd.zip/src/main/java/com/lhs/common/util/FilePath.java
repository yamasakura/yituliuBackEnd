package com.lhs.common.util;

import javax.servlet.http.HttpServletResponse;

public class FilePath {

    public static void createJsonFile(String filePath) {


    }

}
