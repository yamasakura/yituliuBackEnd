package com.lhs.controller.update;

import com.lhs.bean.DBPogo.StageResultData;
import com.lhs.bean.vo.StageResultApiVo;
import com.lhs.common.util.Result;
import com.lhs.dao.StageResultVoApiDao;
import com.lhs.service.ItemService;
import com.lhs.service.StageResultCalcService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@Api(tags = "一图流数据更新")
@CrossOrigin
@RequestMapping(value = "/update")
public class StageResultController {


    @Autowired
    private StageResultCalcService stageResultCalcService;

    @Autowired
    private StageResultVoApiDao stageResultVoApiDao;

    @Autowired
    private ItemService itemService;



    @ApiOperation("更新关卡数据")
    @GetMapping("/stage/calculator/{stageState}/{times}")
    @ApiImplicitParams({
            @ApiImplicitParam(name="stageState",value = "关卡类型",dataType = "Integer",paramType = "path",defaultValue="0",required = false),
            @ApiImplicitParam(name="times",value = "样本量",dataType = "Integer",paramType = "path",defaultValue="300",required = false)})
    public Result update(@PathVariable("stageState") Integer stageState,@PathVariable("times") Integer times) {
        double start = System.currentTimeMillis();//记录程序启动时间



        Double[] versionList = new Double[]{1.0,0.76,0.0,0.625};
        for (int v = 0; v < versionList.length; v++) {

        itemService.resetItemShopValue(versionList[v]);

        List<StageResultData> list = new ArrayList<>();

      int countNum = 9;
      for(int i=0;i<countNum;i++){
          list =  stageResultCalcService.stageResult(i,countNum,times,versionList[v]);
      }

        for(StageResultData rawData:list ){
            if(rawData.getStageState()==1&&stageState==2){
                rawData.setEfficiencyEx(rawData.getEfficiency()+0.045);
            }
            if(rawData.getStageState()==1&&stageState==3){
                if(rawData.getEfficiency().equals(rawData.getEfficiencyEx())){
                    rawData.setStageState(4);
                }else {
                    rawData.setStageState(stageState);
                }

            }
            if(rawData.getIsValue()==0&&stageState==1){
                rawData.setStageState(stageState);
            }
            if(rawData.getIsValue()==1&&stageState==1){
                rawData.setStageState(0);
            }
            if(stageState==0){
                rawData.setStageState(0);
            }

//            System.out.println(rawData);

            rawData.setApExpect(rawData.getApExpect());




        }

        if(v==0){ stageResultCalcService.deleteAllInBatch(); }
        stageResultCalcService.saveAll(list);

        }

        double end = System.currentTimeMillis();
        return Result.success("本次计算用时"+(end - start)/1000+"s");

    }





}
