package com.lhs.controller.update;


import com.alibaba.fastjson.JSONObject;
import com.lhs.bean.DBPogo.Stage;
import com.lhs.bean.vo.RecResultVo;
import com.lhs.bean.vo.StageResultApiVo;
import com.lhs.common.util.Result;
import com.lhs.common.util.ResultCode;
import com.lhs.service.ApiService;
import com.lhs.service.CharTagDataService;
import com.lhs.service.MaaApiService;
import com.lhs.service.StageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

@RestController
@Api(tags = "工具接口")
@RequestMapping(value = "/tool")
@CrossOrigin(maxAge = 86400)
public class ToolController {

    @Autowired
    private ApiService apiService;

    @Autowired
    private StageService stageService;

    @Autowired
    private MaaApiService maaApiService;

    @ApiOperation("更新关卡信息")
    @GetMapping("/update/stage/info/{isShow}/{stageId}")
    public Result updateStageInfo(@PathVariable("isShow") Integer isShow, @PathVariable("stageId") String stageId) {
        stageService.updateStageInfo(isShow, stageId);
        return Result.success();
    }


    @ApiOperation("获取所有关卡信息")
    @GetMapping("/find/stage/info")
    public Result findStageInfo() {
        List<Stage> stageList = stageService.findAll();
        return Result.success(stageList);
    }


    @GetMapping("/visits/{domainName}")
    public Result addVisits(HttpServletRequest request, @PathVariable("domainName") String domainName) {
        apiService.addVisitsAndIp(request, domainName);
        return Result.success();
    }


    @GetMapping("/visits/list/{start}/{end}")
    public Result selectVisits(@PathVariable("start") String start,
                               @PathVariable("end") String end) {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

        List<Object> list = null;
        try {
            list = apiService.selectVisits(simpleDateFormat.parse(start),simpleDateFormat.parse(end) );
        } catch (ParseException e) {
            e.printStackTrace();
        }

        assert list != null;
        if (list.size() > 0) {
            return Result.success(list);
        } else {
            return Result.success(ResultCode.DATA_NONE);
        }
    }

    @ApiOperation("各类公招统计计算")
    @GetMapping("/recruit/calculation")
    public Result MaaTagResultCalculation() {
        double start = System.currentTimeMillis();//记录程序启动时间
        String json = maaApiService.maaTagDataCalculation();
        double end = System.currentTimeMillis();
        HashMap<Object, Object> hashMap = new LinkedHashMap<>();
        hashMap.put("time",(end - start) / 1000);
        hashMap.put("result", JSONObject.parse(json));
        return Result.success(hashMap);
    }

}
