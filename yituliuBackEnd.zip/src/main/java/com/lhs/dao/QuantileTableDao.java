package com.lhs.dao;

import com.lhs.bean.DBPogo.QuantileTable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuantileTableDao extends JpaRepository<QuantileTable, Long> {
}
